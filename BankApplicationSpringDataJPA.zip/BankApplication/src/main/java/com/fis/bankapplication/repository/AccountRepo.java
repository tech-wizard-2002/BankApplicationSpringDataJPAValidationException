package com.fis.bankapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.fis.bankapplication.model.Account;

@Repository
public interface AccountRepo extends JpaRepository<Account,Long> {
	
//	DSL Grammar	
	
////	deposit	
////	@Query("select p from Product p where p.productPrice between ?1 and ?2")	
//	@Modifying
//	@Query("UPDATE Account a SET a.balance = a.balance + :amount WHERE a.id = :accountId")
//	void deposit(@Param("accountId") long accountId, @Param("amount") double amount);
//	
////	withdraw
//	@Modifying
//	@Query("UPDATE Account a SET a.balance = a.balance - :amount WHERE a.id = :accountId")
//	void withdraw(@Param("accountId") long accountId, @Param("amount") double amount);
//	
////	fund transfer
//	@Modifying
//	@Query("UPDATE Account fromAccount, Account toAccount SET fromAccount.balance = fromAccount.balance - :amount, toAccount.balance = toAccount.balance + :amount WHERE fromAccount.id = :fromAccountNumber AND toAccount.id = :toAccountNumber")
//	void fundTransfer(@Param("fromAccountNumber") long fromAccountNumber, @Param("toAccountNumber") long toAccountNumber, @Param("amount") double amount, String transactionType);
		
//	SELECT a FROM Account a WHERE a.customer.id = ?1
	public List<Account> findByCustomer_Id  (long customerId);
    
//	SELECT SUM(a.balance) FROM Account a WHERE a.customer.id = ?1
	@Query("SELECT SUM(a.balance) FROM Account a WHERE a.customer.id = :customerId")
	public double sumBalanceByCustomerId(@Param("customerId") long customerId);

}